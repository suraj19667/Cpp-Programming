//gp series
#include<iostream>
using namespace std;

int gp(){

    int a,r,n;
    cout<<"Enter a:";
    cin>>a;
    cout<<"Enter r:";
    cin>>r;
    cout<<"Enter n:";
    cin>>n;

    for(int i=1;i<=n;i++){
        cout<<a<<endl;
        
    }
    return a=+r;
    
}
int main(){

    cout<<gp();
}