//print numbers with the help of function
#include<iostream>
using namespace std;

void print(int){
    int num;
    cout<<"enter number:";
    cin>>num;
    for(int i=1;i<=num;i++){
    cout<<i;
    }
}
int main(){
    int a;
    print(a);
}