//user define constructor
#include<iostream>
using namespace std;

class demo{

    public:
    demo(int x){

        cout<<x;
    }
};

int main(){

    demo obj(5);
}